﻿using System;
namespace DigitalGates
{
    public class AndGates
    {
        public static bool Input(bool x, bool y)
        {
            return x && y;
        }
    }
}
