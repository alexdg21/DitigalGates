﻿using System;
namespace DigitalGates
{
    public class NotGates
    {
        public static bool Input(bool result)
        {
            if(result == true)
            {
                return false;
            }
            return true;
        }
    }
}
