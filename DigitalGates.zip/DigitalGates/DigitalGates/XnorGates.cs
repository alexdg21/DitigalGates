﻿using System;
namespace DigitalGates
{
    public class XnorGates
    {
        public static bool Input(bool x, bool y)
        {
            if (x ^ y)
            {
                return false;
            }
            else
            {
                return true;
            }
        }
    }
}
