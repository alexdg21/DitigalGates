﻿using System;
namespace DigitalGates
{
    public class NandGates
    {
        public static bool Input(bool x, bool y)
        {
            if (x.Equals(true)
                && y.Equals(true))
            {
                return false;
            }
            else
            {
                return true;
            }
        
        }
    }
}
