﻿using System;
namespace DigitalGates
{
    public class XorGates
    {
        public static bool Input(bool x, bool y)
        {
            if (x ^ y)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
