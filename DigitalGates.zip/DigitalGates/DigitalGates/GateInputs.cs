﻿using System;
namespace DigitalGates
{
    public class GateInputs
    {
        
            public bool X { get; set; }
        
            public bool Y { get; set; }
        
    }
}
