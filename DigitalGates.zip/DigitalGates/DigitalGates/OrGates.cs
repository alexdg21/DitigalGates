﻿using System;
namespace DigitalGates
{
    public class OrGates
    {
        public static bool Input(bool x, bool y)
        {
            return (x || y);
        }
    }
}
